/**
* Triggered when application is started.
* @param {EventArguments} e Returns some attributes about the specified functions
* @this Application
*/
function onLoadGenericTextButton(parent, editBox, options){
    var textButton = new SMF.UI.TextButton({
        top: options.top,
        left: options.left || "10%",
        text: "Set " + options.url,
        onPressed: options.onPressed || function(e) {
            editBox.text = 'http://' + options.url;
        }
    });
    parent.add(textButton);
}

function Global_Events_OnStart(e) {
    changeLang(Device.language, true);
    include("BC.js"); //included for future BC support. Removing is not advised.

    //      Comment following block for navigationbar/actionbar sample. Read the JS code file for usage.
    //      Also there is a part of code block in Page1, which should be copied to every page for HeaderBar usage
    load("HeaderBar.js");
    //header = new HeaderBar();
    
    var scrollView = new SMF.UI.ScrollView({
        top: "10%",
        left: "10%",
        width: "80%",
        height: "80%",
        contentHeight: "100%",
        contentWidth: "100%"
    });
    Pages.Page1.add(scrollView);
    var editBox = new SMF.UI.EditBox({
        left: "10%",
        keyboardType: SMF.UI.KeyboardType.url
    });
    scrollView.add(editBox);
    
    var textButton = new SMF.UI.TextButton({
        left: "10%",
        text: "Load URL",
        onPressed: function(e) {
            var url = editBox.text;
            include(url);
        }
    });
    scrollView.add(textButton);
    onLoadGenericTextButton(scrollView, editBox, {url: '192.168.3.84'});
    onLoadGenericTextButton(scrollView, editBox, {url: '192.168.0.12'});
    onLoadGenericTextButton(scrollView, editBox, {url: 'smartfacefastdebug-serkanserttop-smf.c9.io'});
    onLoadGenericTextButton(scrollView, editBox, {url: '10.0.2.2'});
    onLoadGenericTextButton(scrollView, editBox, {url: '10.0.3.2'});
    var onPressedGenerator = function(editBox, options){
        return function(e){
            var tx = editBox.text;
            editBox.text = tx + options.url;
        }
    };
    onLoadGenericTextButton(scrollView, editBox, {url: ':3000', 
        onPressed: onPressedGenerator(editBox, {url: ':3000'})
    });
    onLoadGenericTextButton(scrollView, editBox, {url: '/smartface', 
        onPressed: onPressedGenerator(editBox, {url: '/smartface'})
    });
    onLoadGenericTextButton(scrollView, editBox, {url: '/main.js', 
        onPressed: onPressedGenerator(editBox, {url: '/main.js'})
    });
    scrollView.layoutType = SMF.UI.LayoutType.linear;
    scrollView.orientation = SMF.UI.Orientation.vertical;
    scrollView.autoSize = true;
    //      Uncomment following block for menu sample. Read the JS code file for usage.
    /*
    load("Menu.js");
    */
    
}
function Global_Events_OnError(e) {
    switch (e.type) {
    case "Server Error":
    case "Size Overflow":
        alert(lang.networkError);
        break;
    default:
        SES.Analytics.eventLog("error", JSON.stringify(e));
        //change the following code for desired generic error messsage
        alert({
            title : lang.applicationError,
            message : e.message + "\n\n*" + e.sourceURL + "\n*" + e.line + "\n*" + e.stack
        });
        break;
    }
}