#include "../inc/SpDefs.h"
#ifdef DEBUGGER_PLAYER
#define SERVER_ADDRESS "192.168.2.81"
#define PORT_1 "2020"
#define PORT_2 "2021"
#endif
